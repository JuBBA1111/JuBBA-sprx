
# JuBBA SPRX (Pattern-Scan + TU Auto-Detect Scaffolding)

This version adds *pattern scanning* scaffolding and *TU auto-detection* for BO2 (MP).
**You still need to provide correct signatures or offsets** for your specific game version (TU).

## What you get
- `pattern_scan.hpp/.cpp`: Minimal Boyer-Moore-Horspool style scanner (byte+mask style) for scanning a memory range.
- `offsets.hpp`: TU enum + signature placeholders for say_bold (and others if you add them).
- `utils.cpp`: Wires `say_bold()` through a resolved function pointer after pattern scan.
- `entry.cpp`: Starts a thread and periodically draws menu page 0.
- `menu.cpp`: Your requested main menu text.
- `Makefile`: Minimal (may require tweaks for your SDK paths).

## You MUST fill:
- Module range resolver in `pattern_scan.cpp` (`get_module_range("default_mp.self", base, size)`) with the real way your SDK provides for grabbing module base/size.
- Correct **signatures** for functions you want to call (e.g., say_bold/CG_PrintToScreen) and their **call wrappers**.
- If you prefer offsets per TU, you can bypass scanning and hardcode addresses in `get_offsets()`.

## Build (example)
```bash
export PS3DEV=$HOME/ps3dev
export PSL1GHT=$HOME/PSL1GHT
export PATH=$PS3DEV/bin:$PS3DEV/ppu/bin:$PS3DEV/spu/bin:$PATH
cd JuBBA-SPRX-Pattern
make clean && make
```

## Pattern format
Use the pattern string format: hex bytes separated by spaces, and mask `?` for wildcards.
Example:
- Pattern:   "48 65 6C 6C 6F ?? 57 6F 72 6C 64"
- Will match "Hello World" with a wildcard at position 5.

## DISCLAIMER
This repo is scaffolding. It won't auto-magically work without your actual signatures/module queries.
