
#include "utils.hpp"
#include <string>

void draw_menu(int page)
{
    switch (page)
    {
        case 0:
            say_bold(
                "==========================\n"
                "     ^2JuBBA Mod Menu\n"
                "==========================\n\n"
                "> Host Options\n"
                "   - Force Host\n"
                "   - Lock Bomb (S&D)\n"
                "   - Unlock Bomb (S&D)\n"
                "   - Restart Game\n"
                "   - Toggle Perma UAV\n\n"
                "> Change Gamemode\n"
                "   - Search & Destroy\n"
                "   - Free For All\n\n"
                "> Switch Weapon (In-Game)\n\n"
                "> Bot Control\n"
                "   - Control Bot Position\n\n"
                "> Player Stats\n"
                "   - Set Prestige (1-16)\n"
                "   - Set Level 55\n"
                "   - Save Stats\n"
                "   - Load Stats\n\n"
                "> Trickshot Menu\n"
                "   - Insta Swap\n"
                "   - Can Swap\n"
                "   - Drop Ballista\n\n"
                "> Killstreak Menu\n"
                "   - UAV\n"
                "   - CUAV\n"
                "   - Care Package\n"
                "   - Lightning Strike\n"
                "   - Sentry Gun\n"
                "   - AGR\n"
                "   - RC-XD\n"
                "   - Hunter Killer\n"
                "   - Hellstorm Missile\n"
                "   - EMP Systems\n\n"
                "> Player Control\n"
                "   - Kick Player\n"
                "   - Ban Player"
            );
            break;
        default:
            say_bold("JuBBA: Page not implemented.");
            break;
    }
}
