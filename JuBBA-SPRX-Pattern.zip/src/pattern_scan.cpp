
#include "pattern_scan.hpp"
#include <vector>
#include <cctype>
#include <cstring>
#include <cstdio>

// STUB: You must implement this using your SDK's module query APIs.
bool get_module_range(const char* module_name, ModuleRange& out)
{
    (void)module_name;
    // Example placeholder (invalid): set to 0 so caller knows it's not ready.
    out.base = 0;
    out.size = 0;
    return false;
}

static int hexval(char c)
{
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    return -1;
}

bool parse_pattern(const std::string& pat, std::vector<uint8_t>& out_bytes, std::vector<uint8_t>& out_mask)
{
    out_bytes.clear(); out_mask.clear();
    for (size_t i = 0; i < pat.size();)
    {
        while (i < pat.size() && isspace(static_cast<unsigned char>(pat[i]))) ++i;
        if (i >= pat.size()) break;

        if (pat[i] == '?' )
        {
            out_bytes.push_back(0x00);
            out_mask.push_back(0x00);
            ++i;
            if (i < pat.size() && pat[i] == '?') ++i; // allow "??"
        }
        else
        {
            if (i + 1 >= pat.size()) return false;
            int hi = hexval(pat[i]); int lo = hexval(pat[i+1]);
            if (hi < 0 || lo < 0) return false;
            out_bytes.push_back(static_cast<uint8_t>((hi<<4) | lo));
            out_mask.push_back(0xFF);
            i += 2;
        }
        while (i < pat.size() && isspace(static_cast<unsigned char>(pat[i]))) ++i;
    }
    return !out_bytes.empty() && out_bytes.size() == out_mask.size();
}

uintptr_t find_pattern(uintptr_t start, size_t size,
                       const std::vector<uint8_t>& pat,
                       const std::vector<uint8_t>& mask)
{
    if (!start || !size || pat.empty() || pat.size() != mask.size()) return 0;
    const uint8_t* hay = reinterpret_cast<const uint8_t*>(start);
    const size_t n = size;
    const size_t m = pat.size();
    size_t i = 0;
    while (i + m <= n)
    {
        size_t j = m;
        while (j > 0)
        {
            uint8_t hb = hay[i + j - 1];
            uint8_t pb = pat[j - 1];
            uint8_t mk = mask[j - 1];
            if (mk && hb != pb) break;
            --j;
        }
        if (j == 0) return start + i;
        ++i; // simple shift; can optimize with BMH table if needed
    }
    return 0;
}
