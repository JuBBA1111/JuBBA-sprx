
#include "utils.hpp"
#include "offsets.hpp"
#include "pattern_scan.hpp"
#include <cstdio>
#include <vector>

using PrintFunc = void(*)(const char*);

static Offsets g_offs{};
static PrintFunc g_print = nullptr;
static GameTU g_tu = GameTU::Unknown;

static uintptr_t resolve_say_bold_by_scan(GameTU tu)
{
    ModuleRange m{};
    if (!get_module_range("default_mp.self", m))
    {
        // Fallback: try "default.self" or "EBOOT.BIN" depending on your loader
        if (!get_module_range("default.self", m) && !get_module_range("EBOOT.BIN", m))
        {
            std::printf("[JuBBA] module range not found; pattern scan disabled.\n");
            return 0;
        }
    }

    const auto& sigs = get_say_bold_patterns(tu);
    for (const auto& s : sigs)
    {
        std::vector<uint8_t> bytes, mask;
        if (!parse_pattern(s.bytes, bytes, mask))
            continue;
        auto addr = find_pattern(m.base, m.size, bytes, mask);
        if (addr)
        {
            return static_cast<uintptr_t>(addr + s.addend);
        }
    }
    return 0;
}

static GameTU detect_tu_by_heuristics()
{
    // TODO: You can hash a known .text range, or check module size to infer TU.
    // For now, return TU18 as default guess.
    return GameTU::TU18;
}

void init_utils()
{
    g_tu = detect_tu_by_heuristics();
    std::printf("[JuBBA] TU guess = %d\n", (int)g_tu);

    auto addr = resolve_say_bold_by_scan(g_tu);
    if (!addr && g_tu != GameTU::TU18) // try a different TU if first guess failed
        addr = resolve_say_bold_by_scan(GameTU::TU18);

    if (addr)
    {
        g_offs.say_bold = addr;
        g_print = reinterpret_cast<PrintFunc>(g_offs.say_bold);
        std::printf("[JuBBA] say_bold resolved @ 0x%08lX\n", (unsigned long)addr);
    }
    else
    {
        std::printf("[JuBBA] say_bold not resolved; fallback to TTY print.\n");
    }
}

void say_bold(const std::string& s)
{
    if (g_print)
    {
        g_print(s.c_str());
    }
    else
    {
        // Fallback: print to TTY
        std::printf("[JuBBA] %s\n", s.c_str());
    }
}
