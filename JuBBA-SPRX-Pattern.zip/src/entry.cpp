
#include <pthread.h>
#include <sys/prx.h>
#include <sys/ppu_thread.h>
#include <sys/timer.h>
#include <cellstatus.h>
#include "utils.hpp"

SYS_MODULE_INFO(JuBBA, 0, 1, 1);
SYS_MODULE_START(_prx_entry);
SYS_MODULE_STOP(_prx_exit);

static sys_ppu_thread_t g_thread = 0;

void* main_thread(void*)
{
    init_utils(); // will run pattern scan + resolve TU
    while (true)
    {
        draw_menu(0);
        sys_timer_usleep(700000); // 0.7s
    }
    return nullptr;
}

extern "C" int _prx_entry(size_t args, void* argv)
{
    (void)args; (void)argv;
    sys_ppu_thread_create(&g_thread, (void*(*)(void*))main_thread, 0, 0x4AA, 0x2000, 0, "JuBBA");
    return SYS_PRX_RESIDENT;
}

extern "C" int _prx_exit()
{
    if (g_thread) sys_ppu_thread_join(g_thread, nullptr);
    return SYS_PRX_STOP_OK;
}
