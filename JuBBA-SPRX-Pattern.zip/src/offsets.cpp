
#include "offsets.hpp"
#include <vector>

// Provide real signatures here (examples are placeholders).
static std::vector<PatternDef> tu1_say_bold = {
    {"say_bold", "DE AD BE EF ?? ?? 13 37", "FFFF00FF", 0}
};
static std::vector<PatternDef> tu6_say_bold = {
    {"say_bold", "DE AD BE EF ?? ?? 73 06", "FFFF00FF", 0}
};
static std::vector<PatternDef> tu17_say_bold = {
    {"say_bold", "DE AD BE EF ?? 17 17 00", "FFF0FFFF", 0}
};
static std::vector<PatternDef> tu18_say_bold = {
    {"say_bold", "DE AD BE EF ?? 18 18 00", "FFF0FFFF", 0}
};

const std::vector<PatternDef>& get_say_bold_patterns(GameTU tu)
{
    switch (tu)
    {
        case GameTU::TU1:  return tu1_say_bold;
        case GameTU::TU6:  return tu6_say_bold;
        case GameTU::TU17: return tu17_say_bold;
        case GameTU::TU18: return tu18_say_bold;
        default:           return tu18_say_bold; // default guess
    }
}
