
#pragma once
#include <cstdint>
#include <string>
#include <vector>

enum class GameTU {
    Unknown = 0,
    TU1, TU6, TU17, TU18
};

struct PatternDef {
    std::string name;
    std::string bytes; // e.g. "48 8D 0D ?? ?? ?? ?? 48 8B D7 E8"
    std::string mask;  // same length as bytes (ignoring spaces), '?' for wildcard
    intptr_t    addend; // offset adjustment after match (e.g., relative call)
};

struct Offsets {
    uintptr_t say_bold; // function pointer to print/bold (to be resolved by scan)
};

// Provide signature sets per TU (fill with your real sigs)
const std::vector<PatternDef>& get_say_bold_patterns(GameTU tu);
