
#pragma once
#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

struct ModuleRange { uintptr_t base; size_t size; };

// TODO: Implement this for your loader—return range for "default_mp.self" (or target module)
bool get_module_range(const char* module_name, ModuleRange& out);

// Convert "AA BB ?? CC" string to bytes + mask
bool parse_pattern(const std::string& pat, std::vector<uint8_t>& out_bytes, std::vector<uint8_t>& out_mask);

// Boyer-Moore-Horspool scan with wildcards
uintptr_t find_pattern(uintptr_t start, size_t size,
                       const std::vector<uint8_t>& pat,
                       const std::vector<uint8_t>& mask);
