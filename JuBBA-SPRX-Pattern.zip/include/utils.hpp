
#pragma once
#include <string>

void init_utils();
void say_bold(const std::string& s);
void draw_menu(int page);
